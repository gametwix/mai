#pragma once

float Square(float a, float b);
char* Translation(long x);